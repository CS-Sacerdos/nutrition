import React, { useState, useEffect } from 'react';
import axios from "axios";

function Register() {
    const [inputId, setInputId] = useState('')
    const [inputPw, setInputPw] = useState('')
    const [inputNm, setInputNm] = useState('')

    // input data 의 변화가 있을 때마다 value 값을 변경해서 useState 해준다
    const handleInputId = (e) => {
        setInputId(e.target.value)
    }

    const handleInputPw = (e) => {
        setInputPw(e.target.value)
    }

    const handleInputNm = (e) => {
        setInputNm(e.target.value)
    }

    const onClickRegister = () =>{
        console.log('click register')
        axios.post('/user_inform/onRegister', null, {
            params: {
                'user_id': inputId,
                'user_pw': inputPw,
                'user_name': inputNm
            }
        }).then(res => console.log(res) )
            .catch()
    }

    return(
        <div className="pages">
            <h2>Register</h2>
            <div>
                <label htmlFor='input_id'>ID : </label>
                <input type='text' name='input_id' value={inputId} onChange={handleInputId} />
            </div>
            <div>
                <label htmlFor='input_pw'>PW : </label>
                <input type='password' name='input_pw' value={inputPw} onChange={handleInputPw} />
            </div>
            <div>
                <label htmlFor='input_name'>이름 : </label>
                <input type='text' name='input_name' value={inputNm} onChange={handleInputNm} />
            </div>
            <div>
                <button type='button' onClick={onClickRegister}>Register</button>
            </div>
        </div>
    )
}

export default Register