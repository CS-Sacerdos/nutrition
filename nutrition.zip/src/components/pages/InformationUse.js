import React from 'react';


function InformationUse()
{
    return (
        <div className="pages">
            <h1>이용안내</h1>
        </div>
    );
}

export default InformationUse;