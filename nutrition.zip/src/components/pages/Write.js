import {Helmet} from "react-helmet";

function Write(){
    return(
        <Helmet>


        </Helmet>
    )
}

export default Write;